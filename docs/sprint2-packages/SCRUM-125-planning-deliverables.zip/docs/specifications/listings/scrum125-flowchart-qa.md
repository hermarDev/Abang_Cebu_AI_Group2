# SCRUM-125 Flowchart Validation Notes

This is a validation record, not a renderer. Run `python scripts/render_flowchart_previews.py` to create SVG previews from editable Draw.io sources.

## `landlord-listing-draft-submit`
- PASS (logical/structural): authenticated session and landlord role gates; valid/invalid property and unit paths; save-draft and pending-review handoff; persistence gate to end; no disconnected nodes or unresolved endpoints.
- Draw.io XML parses; SVG and PDF render outputs exist.
- Independent visual inspection: no overlapping nodes/connectors detected; branch labels readable; top-to-bottom layout clear.

## `landlord-listing-review-outcomes`
- REWORK (original): approval/rejection branches were conflated; no-resubmit route ended at incorrect state; resubmit outcome was not clear.
- Current independent reviews: Two tracked Combo_V4/OmniRoute logical reviews pass checked SCRUM-125 paths; the latest also finds both source graphs reachable, endpoint-complete and geometrically non-overlapping. Exports cannot be confirmed current because their timestamps differ from the Draw.io sources; native-size legibility was not verified. Schema/RLS, product-policy and integration retry/idempotency decisions remain blocked. Reviewers made no edits or Jira changes.
- Current verification (Orchestrator, 2026-10-16): the source XML and regenerated SVG/PNG/PDF confirm approval → approved persistence → availability check → public/hidden discovery. Rejection without resubmission terminates rejected/non-public. Rejection with resubmission alone reaches the pending-review outcome. XML has 16 edges and no dangling endpoints.
- Independent visual review is blocked (not performed); schema/RLS and product-owner approval required for draft persistence and rejected-listing resubmission. Do not mark SCRUM-125 Done until gates are resolved.

`python scripts/render_flowchart_previews.py` generates editable-source SVG previews with orthogonal, obstacle-aware connectors. PDF/PNG exports are generated from SVG previews, not directly exported by diagrams.net.
